package com.olawale.minipay.data.models

import com.google.gson.annotations.SerializedName

/**
 * Transaction Model for MiniPay
 * Developed by Olawale Abdul-Ganiyu
 */
data class Transaction(
    @SerializedName("id")
    val id: String,
    
    @SerializedName("userId")
    val userId: String,
    
    @SerializedName("type")
    val type: TransactionType,
    
    @SerializedName("amount")
    val amount: Double,
    
    @SerializedName("currency")
    val currency: String = "USD",
    
    @SerializedName("description")
    val description: String,
    
    @SerializedName("recipientName")
    val recipientName: String? = null,
    
    @SerializedName("recipientAccount")
    val recipientAccount: String? = null,
    
    @SerializedName("status")
    val status: TransactionStatus,
    
    @SerializedName("fee")
    val fee: Double = 0.0,
    
    @SerializedName("createdAt")
    val createdAt: String,
    
    @SerializedName("completedAt")
    val completedAt: String? = null
) {
    enum class TransactionType {
        CREDIT,
        DEBIT,
        TRANSFER_SEND,
        TRANSFER_RECEIVE,
        WITHDRAWAL,
        DEPOSIT
    }
    
    enum class TransactionStatus {
        PENDING,
        COMPLETED,
        FAILED,
        CANCELLED
    }
    
    fun getFormattedAmount(): String {
        val sign = when (type) {
            TransactionType.CREDIT,
            TransactionType.TRANSFER_RECEIVE,
            TransactionType.DEPOSIT -> "+"
            TransactionType.DEBIT,
            TransactionType.TRANSFER_SEND,
            TransactionType.WITHDRAWAL -> "-"
        }
        return "$sign$$${String.format("%.2f", amount)}"
    }
    
    fun getTypeDisplayName(): String {
        return when (type) {
            TransactionType.CREDIT -> "Credit"
            TransactionType.DEBIT -> "Debit"
            TransactionType.TRANSFER_SEND -> "Transfer Sent"
            TransactionType.TRANSFER_RECEIVE -> "Transfer Received"
            TransactionType.WITHDRAWAL -> "Withdrawal"
            TransactionType.DEPOSIT -> "Deposit"
        }
    }
    
    fun getStatusColor(): String {
        return when (status) {
            TransactionStatus.COMPLETED -> "#10b981"
            TransactionStatus.PENDING -> "#f59e0b"
            TransactionStatus.FAILED -> "#ef4444"
            TransactionStatus.CANCELLED -> "#6b7280"
        }
    }
}