package com.olawale.minipay.data.models

import com.google.gson.annotations.SerializedName

/**
 * User Model for MiniPay
 * Developed by Olawale Abdul-Ganiyu
 */
data class User(
    @SerializedName("id")
    val id: String,
    
    @SerializedName("fullName")
    val fullName: String,
    
    @SerializedName("email")
    val email: String,
    
    @SerializedName("phone")
    val phone: String,
    
    @SerializedName("accountNumber")
    val accountNumber: String,
    
    @SerializedName("balance")
    var balance: Double,
    
    @SerializedName("currency")
    val currency: String = "USD",
    
    @SerializedName("isVerified")
    var isVerified: Boolean = false,
    
    @SerializedName("isAdmin")
    var isAdmin: Boolean = false,
    
    @SerializedName("googleAccount")
    var googleAccount: String? = null,
    
    @SerializedName("createdAt")
    val createdAt: String,
    
    @SerializedName("updatedAt")
    var updatedAt: String = createdAt
) {
    companion object {
        fun empty() = User(
            id = "",
            fullName = "",
            email = "",
            phone = "",
            accountNumber = "",
            balance = 0.0,
            createdAt = ""
        )
    }
    
    fun getFormattedBalance(): String {
        return "$${String.format("%.2f", balance)}"
    }
    
    fun getMaskedAccountNumber(): String {
        return if (accountNumber.length >= 4) {
            "**** ${accountNumber.takeLast(4)}"
        } else {
            accountNumber
        }
    }
}