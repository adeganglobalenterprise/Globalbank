package com.olawale.minipay

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.Gson
import com.google.gson.GsonBuilder

/**
 * MiniPay Application
 * Developed by Olawale Abdul-Ganiyu
 * Global Digital Wallet Application
 */
class MiniPayApplication : Application() {
    
    companion object {
        lateinit var instance: MiniPayApplication
            private set
        
        // API Configuration
        const val API_BASE_URL = "https://api.olawale-minipay.com/v2/"
        const val API_TIMEOUT = 30000L
        
        // App Configuration
        const val APP_NAME = "MiniPay"
        const val APP_VERSION = "2.0.0"
        const val OWNER_NAME = "olawale abdul-ganiyu"
        const val GOOGLE_ACCOUNT = "olawalztegan@gmail.com"
        
        // Security Configuration
        const val ENCRYPTION_KEY = "MiniPay_Secure_Key_2025"
        const val BIOMETRIC_ENABLED = true
        
        // Firebase Configuration
        const val FIREBASE_PROJECT_ID = "minipay-olawale"
        
        // Admin Credentials (Should be stored securely in production)
        const val ADMIN_EMAIL = "olawalztegan@gmail.com"
        const val ADMIN_PASSWORD = "admin_secure_2025"
        
        val gson: Gson = GsonBuilder()
            .setLenient()
            .create()
        
        val auth: FirebaseAuth by lazy {
            FirebaseAuth.getInstance()
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        
        // Initialize Firebase
        initializeFirebase()
        
        // Initialize Security
        initializeSecurity()
        
        // Initialize Database
        initializeDatabase()
    }
    
    private fun initializeFirebase() {
        try {
            FirebaseApp.initializeApp(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    private fun initializeSecurity() {
        // Initialize biometric authentication
        // Initialize encryption
        // Initialize secure storage
    }
    
    private fun initializeDatabase() {
        // Initialize local database
        // Initialize shared preferences
        // Initialize secure storage for sensitive data
    }
}